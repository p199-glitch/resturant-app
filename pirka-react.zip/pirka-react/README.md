# Pirka Khaja Ghar — React Frontend

Vite + React 18 + React Router v6

## Quick Start
npm install
npm run dev        # http://localhost:5173
npm run build      # production build

## Structure
src/
  components/  Navbar, Footer, StickyCTA, DishCard
  pages/       Home, Menu, About, Gallery, Contact
  styles/      global.css (design tokens)

## Routes
/          Home
/menu      Menu (with filters)
/about     About Us
/gallery   Gallery + lightbox
/contact   Contact + Reservation form

## Backend
Form posts to http://localhost:5000/api/reservations
Change API_URL in src/pages/Contact.jsx for production.

## Deploy
npm run build → drag dist/ to netlify.com/drop
Add public/_redirects: /*  /index.html  200
