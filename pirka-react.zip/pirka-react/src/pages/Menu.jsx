import { useState } from 'react'
import DishCard from '../components/DishCard'
import Footer from '../components/Footer'
import './Menu.css'

const MENU = [
  // Starters
  { id: 1,  name: 'Vegetable Momo',   desc: 'Steamed dumplings filled with cabbage, carrots & spices with sesame achar.',             price: 160,  cat: 'starters',  veg: true  },
  { id: 2,  name: 'Buffalo Momo',     desc: 'Juicy buffalo-stuffed momos, steamed to perfection with aromatic spices.',                price: 180,  cat: 'starters',  veg: false },
  { id: 3,  name: 'Fried Momo',       desc: 'Crispy golden-fried momos served with spicy tomato chutney.',                             price: 200,  cat: 'starters',  veg: false },
  { id: 4,  name: 'Sel Roti & Achar', desc: 'Crispy homemade rice ring bread with tangy tomato achar on the side.',                    price: 120,  cat: 'starters',  veg: true  },
  { id: 5,  name: 'Chatamari',        desc: 'Newari rice crepe topped with minced meat, egg and aromatic herbs.',                      price: 220,  cat: 'starters',  veg: false },
  { id: 6,  name: 'Alu Chop',         desc: 'Deep fried potato patties spiced with ginger, garlic and coriander.',                    price: 100,  cat: 'starters',  veg: true  },
  { id: 7,  name: 'Buff Sekuwa',      desc: 'Charcoal-grilled marinated buffalo — a Newari barbecue tradition.',                       price: 350,  cat: 'starters',  veg: false },
  // Mains
  { id: 8,  name: 'Dal Bhat Tarkari', desc: 'Classic set with lentil soup, steamed rice, seasonal veg & pickle. Unlimited refills.',   price: 250,  cat: 'mains',     veg: true  },
  { id: 9,  name: 'Chicken Curry Set',desc: 'Rich, slow-cooked chicken curry with rice and seasonal greens.',                          price: 380,  cat: 'mains',     veg: false },
  { id: 10, name: 'Vegetable Thukpa', desc: 'Hearty Tibetan noodle soup loaded with fresh mountain vegetables.',                       price: 200,  cat: 'mains',     veg: true  },
  { id: 11, name: 'Mutton Curry',     desc: 'Slow-cooked mutton in a spiced tomato-based gravy, best with roti.',                     price: 450,  cat: 'mains',     veg: false },
  { id: 12, name: 'Gundruk Saag',     desc: 'Fermented leafy greens sautéed with garlic and mustard seeds.',                          price: 160,  cat: 'mains',     veg: true  },
  { id: 13, name: 'Macha Ko Jhol',    desc: 'River fish in a tangy, turmeric-rich Nepali curry sauce with steamed rice.',              price: 400,  cat: 'mains',     veg: false },
  // Drinks
  { id: 14, name: 'Mango Lassi',      desc: 'Thick, chilled yogurt drink blended with Alphonso mango and cardamom.',                  price: 130,  cat: 'drinks',    veg: true  },
  { id: 15, name: 'Masala Chiya',     desc: 'Our signature spiced milk tea with ginger, cardamom, cloves and cinnamon.',               price: 60,   cat: 'drinks',    veg: true  },
  { id: 16, name: 'Kagati Pani',      desc: 'Fresh-squeezed lemon with black salt, cumin and mint over ice.',                         price: 90,   cat: 'drinks',    veg: true  },
  { id: 17, name: 'Sugarcane Juice',  desc: 'Freshly pressed sugarcane with a dash of ginger and lime.',                              price: 80,   cat: 'drinks',    veg: true  },
  // Desserts
  { id: 18, name: 'Yomari',           desc: 'Steamed rice-flour dumplings filled with sweet chaku and sesame.',                       price: 150,  cat: 'desserts',  veg: true  },
  { id: 19, name: 'Rice Kheer',       desc: 'Creamy slow-cooked rice pudding with saffron, cardamom and pistachios.',                 price: 120,  cat: 'desserts',  veg: true  },
  { id: 20, name: 'Juju Dhau',        desc: "Bhaktapur's king of yogurt — thick, creamy and naturally sweet. Served in clay cups.",   price: 100,  cat: 'desserts',  veg: true  },
]

const CATEGORIES = [
  { key: 'all',      label: 'All'        },
  { key: 'starters', label: 'Starters'   },
  { key: 'mains',    label: 'Main Course'},
  { key: 'drinks',   label: 'Drinks'     },
  { key: 'desserts', label: 'Desserts'   },
]

const CAT_LABELS = {
  starters: 'Starters & Snacks',
  mains:    'Main Course',
  drinks:   'Drinks',
  desserts: 'Desserts',
}

export default function Menu() {
  const [activeFilter, setActiveFilter] = useState('all')
  const [vegOnly, setVegOnly] = useState(false)

  const filtered = MENU.filter(item => {
    const catMatch = activeFilter === 'all' || item.cat === activeFilter
    const vegMatch = !vegOnly || item.veg
    return catMatch && vegMatch
  })

  const categories = activeFilter === 'all'
    ? ['starters', 'mains', 'drinks', 'desserts']
    : [activeFilter]

  return (
    <div className="page-enter">
      <div className="page-hero">
        <span className="section-tag">What We Serve</span>
        <h1 className="section-title">Our Menu</h1>
        <p className="sub">Fresh ingredients, traditional recipes, crafted daily.</p>
      </div>

      <div className="filter-bar">
        {CATEGORIES.map(c => (
          <button
            key={c.key}
            className={`filter-btn ${activeFilter === c.key && !vegOnly ? 'active' : ''}`}
            onClick={() => { setActiveFilter(c.key); setVegOnly(false) }}
          >
            {c.label}
          </button>
        ))}
        <button
          className={`filter-btn veg-btn ${vegOnly ? 'active' : ''}`}
          onClick={() => { setVegOnly(v => !v); setActiveFilter('all') }}
        >
          <span className="veg-indicator" /> Veg Only
        </button>
      </div>

      <div className="menu-section">
        {categories.map(cat => {
          const items = filtered.filter(i => i.cat === cat)
          if (!items.length) return null
          return (
            <div className="menu-category" key={cat}>
              <div className="menu-cat-title">
                <span className="dash">—</span> {CAT_LABELS[cat]}
              </div>
              <div className="menu-grid">
                {items.map(item => (
                  <DishCard
                    key={item.id}
                    name={item.name}
                    description={item.desc}
                    price={item.price}
                    isVeg={item.veg}
                    imgLabel={item.name}
                    imgHeight={140}
                  />
                ))}
              </div>
            </div>
          )
        })}
      </div>

      <Footer />
    </div>
  )
}
