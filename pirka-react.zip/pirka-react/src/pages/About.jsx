import Footer from '../components/Footer'
import './About.css'

const VALUES = [
  { title: 'Authenticity', body: 'We never compromise on traditional recipes, ingredients, or preparation methods.' },
  { title: 'Community',    body: 'We source from local farmers and support Kathmandu\'s artisan community.' },
  { title: 'Warmth',       body: 'Every guest leaves feeling like they\'ve been fed by a Nepali family.' },
  { title: 'Quality',      body: 'Fresh ingredients every morning. No shortcuts. No frozen food. Ever.' },
]

export default function About() {
  return (
    <div className="page-enter">

      {/* Hero split */}
      <section className="about-hero">
        <div className="about-hero-img">
          <div className="img-ph" style={{ height: '100%', minHeight: 480 }}>
            <span>Restaurant Photo</span>
          </div>
        </div>
        <div className="about-hero-text">
          <span className="section-tag">Our Story</span>
          <h1 className="section-title" style={{ marginBottom: '1.5rem' }}>
            Born from a Mother's Kitchen
          </h1>
          <p className="about-intro">
            Pirka Khaja Ghar opened its doors in 2008 with a simple dream — to share
            the food that grandmother Devi Shrestha cooked for her family in Bhaktapur.
            Today, that same spirit lives in every plate we serve.
          </p>
        </div>
      </section>

      {/* Story */}
      <section className="about-story">
        <div className="about-story-sticky">
          <span className="section-tag">Our Journey</span>
          <h2 className="section-title" style={{ marginBottom: '1.5rem' }}>
            Rooted in Tradition
          </h2>
          <div className="img-ph" style={{ height: 280, borderRadius: 4, marginTop: '2rem' }}>
            <span>Vintage Photo</span>
          </div>
        </div>
        <div className="about-story-text">
          <p>It all began in a small rented room in Thamel, where Bishnu Shrestha started cooking his mother's recipes for a handful of curious travellers. Word spread quickly. The food was honest, warm, and deeply Nepali.</p>
          <p>Within two years, Pirka Khaja Ghar had moved to its current home — a two-storey eatery with hand-painted walls, wooden carvings from Bhaktapur artisans, and a courtyard filled with clay pots of flowering marigolds.</p>
          <p>Over fifteen years later, the third generation of the Shrestha family now runs the kitchen. The recipes have not changed. The welcome has only grown warmer.</p>
          <p>We are proud to be a place where Kathmandu locals celebrate their milestones, where tourists taste their first authentic momo, and where travellers from across the world find a home-cooked meal far from home.</p>

          <h3 className="values-heading">Our Values</h3>
          <div className="values-grid">
            {VALUES.map(v => (
              <div className="value-card" key={v.title}>
                <h4>{v.title}</h4>
                <p>{v.body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Chef */}
      <section className="chef-section">
        <div className="chef-header">
          <span className="section-tag">Meet the Team</span>
          <h2 className="section-title">The Heart of Our Kitchen</h2>
        </div>
        <div className="chef-inner">
          <div className="chef-img">
            <div className="img-ph" style={{ height: 360, borderRadius: 4 }}>
              <span>Chef Photo</span>
            </div>
          </div>
          <div className="chef-bio">
            <div className="chef-name">Chef Sushila Shrestha</div>
            <div className="chef-title">Head Chef & Co-Founder</div>
            <p>Sushila learned to cook at her grandmother's side in Bhaktapur, mastering the slow rhythm of Newari cuisine — the careful balance of spices, the patience of slow-cooked curries, the precision of perfect momos.</p>
            <p>She trained further in Darjeeling before returning to Kathmandu to open Pirka. Her philosophy is simple: cook the way you would for someone you love.</p>
            <p>In 2019, Sushila was featured in Nepali Times as one of the ten most influential women shaping Kathmandu's food culture.</p>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}
